//package dtm;
//
//import io.github.bonigarcia.wdm.WebDriverManager;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.Assert;
//import org.testng.annotations.*;
//import java.time.Duration;
//
//public class LoginTest {
//    WebDriver driver;
//    WebDriverWait wait;
//
//    // Thêm alwaysRun = true để TestNG không bỏ qua hàm này khi chạy theo group
//    @BeforeMethod(alwaysRun = true)
//    public void setUp() {
//        WebDriverManager.chromedriver().setup();
//        driver = new ChromeDriver();
//        driver.manage().window().maximize();
//        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        driver.get("https://www.saucedemo.com");
//    }
//
//    // Gán nhóm smoke và regression
//    @Test(description = "testLoginSuccess", groups = {"smoke", "regression"})
//    public void testLoginSuccess() {
//        driver.findElement(By.id("user-name")).sendKeys("standard_user");
//        driver.findElement(By.id("password")).sendKeys("secret_sauce");
//        driver.findElement(By.id("login-button")).click();
//        wait.until(ExpectedConditions.urlContains("/inventory.html"));
//        Assert.assertTrue(driver.getCurrentUrl().contains("/inventory.html"), "Lỗi: Không chuyển hướng sang trang inventory!");
//    }
//
//    // Các test còn lại chỉ gán nhóm regression
//    @Test(description = "testLoginWrongPassword", groups = {"regression"})
//    public void testLoginWrongPassword() {
//        driver.findElement(By.id("user-name")).sendKeys("standard_user");
//        driver.findElement(By.id("password")).sendKeys("wrong_password");
//        driver.findElement(By.id("login-button")).click();
//        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h3[data-test='error']")));
//        Assert.assertTrue(errorMsg.isDisplayed(), "Lỗi: Thông báo sai mật khẩu không hiển thị!");
//    }
//
//    @Test(description = "testLoginEmptyUsername", groups = {"regression"})
//    public void testLoginEmptyUsername() {
//        driver.findElement(By.id("password")).sendKeys("secret_sauce");
//        driver.findElement(By.id("login-button")).click();
//        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h3[data-test='error']")));
//        Assert.assertTrue(errorMsg.getText().contains("Username is required"), "Lỗi: Sai thông báo trống Username!");
//    }
//
//    @Test(description = "testLoginEmptyPassword", groups = {"regression"})
//    public void testLoginEmptyPassword() {
//        driver.findElement(By.id("user-name")).sendKeys("standard_user");
//        driver.findElement(By.id("login-button")).click();
//        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h3[data-test='error']")));
//        Assert.assertTrue(errorMsg.getText().contains("Password is required"), "Lỗi: Sai thông báo trống Password!");
//    }
//
//    @Test(description = "testLoginLockedUser", groups = {"regression"})
//    public void testLoginLockedUser() {
//        driver.findElement(By.id("user-name")).sendKeys("locked_out_user");
//        driver.findElement(By.id("password")).sendKeys("secret_sauce");
//        driver.findElement(By.id("login-button")).click();
//        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h3[data-test='error']")));
//        Assert.assertTrue(errorMsg.getText().contains("Sorry, this user has been locked out"), "Lỗi: Sai thông báo khóa tài khoản!");
//    }
//
//    // Thêm alwaysRun = true để TestNG luôn đóng trình duyệt
//    @AfterMethod(alwaysRun = true)
//    public void tearDown() {
//        driver.quit();
//    }
//}

package dtm;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import java.time.Duration;

public class LoginTest {
    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        // Gọi Nhà máy để tạo trình duyệt Chrome an toàn cho đa luồng
        DriverFactory.initDriver("chrome");
        driver = DriverFactory.getDriver();

        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com");
    }

    @Test(description = "testLoginSuccess", groups = {"smoke", "regression"})
    public void testLoginSuccess() {
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
        wait.until(ExpectedConditions.urlContains("/inventory.html"));
        Assert.assertTrue(driver.getCurrentUrl().contains("/inventory.html"), "Lỗi: Không chuyển hướng sang trang inventory!");
    }

    @Test(description = "testLoginWrongPassword", groups = {"regression"})
    public void testLoginWrongPassword() {
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("wrong_password");
        driver.findElement(By.id("login-button")).click();
        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h3[data-test='error']")));
        Assert.assertTrue(errorMsg.isDisplayed(), "Lỗi: Thông báo sai mật khẩu không hiển thị!");
    }

    @Test(description = "testLoginEmptyUsername", groups = {"regression"})
    public void testLoginEmptyUsername() {
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h3[data-test='error']")));
        Assert.assertTrue(errorMsg.getText().contains("Username is required"), "Lỗi: Sai thông báo trống Username!");
    }

    @Test(description = "testLoginEmptyPassword", groups = {"regression"})
    public void testLoginEmptyPassword() {
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("login-button")).click();
        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h3[data-test='error']")));
        Assert.assertTrue(errorMsg.getText().contains("Password is required"), "Lỗi: Sai thông báo trống Password!");
    }

    @Test(description = "testLoginLockedUser", groups = {"regression"})
    public void testLoginLockedUser() {
        driver.findElement(By.id("user-name")).sendKeys("locked_out_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h3[data-test='error']")));
        Assert.assertTrue(errorMsg.getText().contains("Sorry, this user has been locked out"), "Lỗi: Sai thông báo khóa tài khoản!");
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        // Gọi Nhà máy để thu hồi và đóng trình duyệt
        DriverFactory.quitDriver();
    }
}