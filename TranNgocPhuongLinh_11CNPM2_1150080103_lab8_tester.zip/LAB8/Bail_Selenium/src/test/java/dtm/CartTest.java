//package dtm;
//
//import org.testng.annotations.Test;
//
//public class CartTest {
//
//    @Test(groups = {"smoke", "regression"})
//    public void testAddToCart() {
//        System.out.println("=> Chay CartTest: Them vao gio hang (nhom smoke)");
//    }
//
//    @Test(groups = {"regression"})
//    public void testRemoveFromCart() {
//        System.out.println("=> Chay CartTest: Xoa khoi gio hang (nhom regression)");
//    }
//}

package dtm;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CartTest {
    WebDriver driver;

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        // Tương tự, gọi Nhà máy tạo trình duyệt
        DriverFactory.initDriver("chrome");
        driver = DriverFactory.getDriver();

        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com");
    }

    @Test(groups = {"smoke", "regression"})
    public void testAddToCart() {
        System.out.println("=> Chay CartTest: Them vao gio hang (nhom smoke, regression)");
    }

    @Test(groups = {"regression"})
    public void testRemoveFromCart() {
        System.out.println("=> Chay CartTest: Xoa khoi gio hang (nhom regression)");
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        // Gọi Nhà máy để thu hồi và đóng trình duyệt
        DriverFactory.quitDriver();
    }
}