package dtm;

import org.testng.annotations.Test;

public class CheckoutTest {

    @Test(groups = {"smoke", "regression"})
    public void testCheckoutSuccess() {
        System.out.println("=> Chay CheckoutTest: Thanh toan thanh cong (nhom smoke)");
    }

    @Test(groups = {"regression"})
    public void testCheckoutFail() {
        System.out.println("=> Chay CheckoutTest: Thanh toan that bai (nhom regression)");
    }
}